#include<stdio.h>

int main(){
    // char str[] = {'H', 'a', 'r', 'r', 'y', '\0'};
    char str[] = "Harry";
    
    return 0;
}