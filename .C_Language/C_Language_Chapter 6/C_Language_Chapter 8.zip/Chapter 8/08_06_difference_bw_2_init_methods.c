#include<stdio.h>

int main(){ 
    char *ptr = "Harry Bhai";
    // char ptr[] = "Harry Bhai";
    ptr = "Shubham bhai";
    printf("%s", ptr);
    return 0;
}