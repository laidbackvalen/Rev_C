#include<stdio.h>

int main(){
    // int a = 4;
    // printf("%d", a);

    // char *ptr = "Harry bhai";
    char ptr[] = "Harry bhai";
    printf("%s", ptr);
    return 0;
}